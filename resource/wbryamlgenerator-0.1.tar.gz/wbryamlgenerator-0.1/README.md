# Generate the WBR yaml using AI

## Overview

This project is mainly built to help you generate yaml files for any large datasets. The yaml generator scripts takes your csv data and builds a config that will work with the WBR App. 
To accomplish this we have used OpenAI's GPT-4o model to generate the config for you. 

## Prerequisites

You need to create a OpenAI account for yourself and generate a API keys. You can do so by following the documentation https://platform.openai.com/docs/quickstart.

## Installing steps

### Installing WBR AI YAML GENERATOR
#### Mac / Linux
1. **Set Up a Python Virtual Environment**  
    Create a virtual environment in the `wbr-app` directory by running the following command:
      ```bash
      python3.12 -m venv "venv"
      ```
2. **Activate the Virtual Environment**  
    Activate the virtual environment by running:
      ```bash
      source venv/bin/activate
      ```
3. **Install Dependencies**  
    Once the virtual environment is active, install the required packages:
      ```bash
      pip install -r requirements.txt
      ```

#### Windows
1. **Set Up a Python Virtual Environment**  
    Create a virtual environment in the `wbr-app` directory by running the following command:
      ```bash
      py -m venv venv
      ```
2. **Activate the Virtual Environment**  
    To activate the virtual environment
   - Change to the venv\Scripts directory:
       ```bash
       cd venv\Scripts
       ```
   - Type activate and press enter to activate the environment:
       ```bash
       activate
       ```
3. **Return to the Project Directory**  
    Navigate back to the `wbr-app` directory:
      ```bash
      cd ..\..\
      ```
4. **Install Dependencies**  
    Once the virtual environment is active, install the required packages:
      ```bash
      pip install -r requirements.txt
      ```

### BUILDING THE DISTRIBUTION
1. **Run Build command**
    Once the setup is complete with the virtual environment, run the following command to build the distribution
      ```bash
      python -m build
      ```
    After a successful build you will see a `/dist` directory being created 

### INSTALLING DISTRIBUTION IN WBR-APP
1. **Copy File**
    Copy either of built files from the `/dist` directory to the main WBR project https://github.com/working-backwards/wbr-app
2. **Install the distribution**
    Run the following command to install the distribution
      ```bash
      pip install <path-to-yaml-generator-lib>/wbryamlgenerator-0.1.tar.gz
      ```
3. **Configure Environment**
    Configure the OpenAI environment variables. You can follow the same quickstart documentation by OpenAI to configure you environment variables

    Now you are ready to generate the yaml configuration for your csv data using AI.