from distutils.core import setup

from setuptools import find_packages

print(find_packages())

setup(
    name='wbryamlgenerator',
    version='0.1',
    packages=find_packages(),
    long_description=open('README.md').read(),
    install_requires=[
        'openai==2.7.1',
        'langchain==1.0.5',
        'setuptools~=80.9.0',
        'PyYAML~=6.0.3'
    ]
)
